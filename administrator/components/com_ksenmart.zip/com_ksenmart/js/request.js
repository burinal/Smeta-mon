jQuery(document).ready(function() {

    jQuery('.edit').height(jQuery(window).height() - 40);

});