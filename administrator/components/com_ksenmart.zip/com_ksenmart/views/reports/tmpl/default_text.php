<?php 
/**
 * @copyright   Copyright (C) 2013. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
 
defined('_JEXEC') or die;
?>
<table class="cat" width="100%" cellspacing="0">	
	<thead>
		<tr>
			<th>&nbsp;</th>
		</tr>
	</thead>	
	<tbody>
		<tr>
			<td>
				<h1 align="center"><?php echo JText::_('ksm_reports_choose_report')?></h1>
			</td>	
		</tr>
	</tbody>
</table>	