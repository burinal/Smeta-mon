<?php 
/**
 * @copyright   Copyright (C) 2013. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
 
defined('_JEXEC') or die;
?>
<tr class="no_list_items">
	<td colspan="6"><h1 align="center"><?php echo JText::_('ksm_no_list_items')?></h1></td>
</tr>	