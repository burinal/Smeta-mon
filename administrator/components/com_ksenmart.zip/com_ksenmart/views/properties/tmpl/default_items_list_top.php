<?php 
/**
 * @copyright   Copyright (C) 2013. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
 
defined('_JEXEC') or die;
?>
<div class="top ">
	<a class="adds km-modal" rel='{"x":"90%","y":"90%"}' href="<?php echo JRoute::_('index.php?option=com_ksenmart&view=properties&layout=property&tmpl=component');?>"><?php echo JText::_('ksm_properies_add_property')?></a>
	<a class="button delete-items"><?php echo JText::_('ksm_delete')?></a>
</div>