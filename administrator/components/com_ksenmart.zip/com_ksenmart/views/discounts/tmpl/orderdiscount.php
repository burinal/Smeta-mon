<?php
/**
 * @copyright   Copyright (C) 2013. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
?>
<div class="position">
    <label class="inputname_response"><?php echo $this->item->title;?>: <strong></strong></label>
    <a href="#" class="del"></a>
</div>