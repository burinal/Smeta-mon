DROP TABLE
	`#__ksenmart_discount_coupons`;